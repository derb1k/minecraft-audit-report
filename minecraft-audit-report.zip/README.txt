﻿Minecraft audit report
Instance folder: LS
Created: 2026-10-24 22:31:19
Mods inventoried: 420
Text files copied: 700

Review logs and configs for personal information before sharing.
This report does not intentionally include worlds, saves, screenshots,
resource packs or the full contents of mod JAR files.
